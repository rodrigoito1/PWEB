
function MaiorValor(){
    var n1 = parseFloat(prompt("Digite o primeiro numero"));
    var n2 =  parseFloat(prompt("Digite o segundo numero"));
    var n3 =  parseFloat(prompt("Digite o terceiro numero"));
    
    if(n1>n2 && n1>n3){
        alert("O maior valor é" + n1)
    };

    if(n2>n1 && n2>n3){
        alert("O maior valor é " + n2)
    }
    if(n3>n1 && n3>n2){
        alert("O maior valor é " + n3)
    }
}


function OrdenarCrescente() {
    let menor, meio, maior;
    
    var a = parseFloat(prompt("Digite o primeiro numero"));
    var b = parseFloat(prompt("Digite o segundo numero"));
    var c = parseFloat(prompt("Digite o terceiro numero"));

    if (a <= b && a <= c) {
      menor = a;
      if (b <= c) {
        meio = b;
        maior = c;
      } else {
        meio = c;
        maior = b;
      }
    } else if (b <= a && b <= c) {
      menor = b;
      if (a <= c) {
        meio = a;
        maior = c;
      } else {
        meio = c;
        maior = a;
      }
    } else {
      menor = c;
      if (a <= b) {
        meio = a;
        maior = b;
      } else {
        meio = b;
        maior = a;
      }
    }
  
    alert(menor);
    alert(meio);
    alert(menor);
  }

function Palindromo(){
    var x = prompt("Digite a palavra que deseja saber se é palindromo: ");

}

function Triangulo(){
    var a = parseFloat(prompt("Digite o primeiro numero"));
    var b = parseFloat(prompt("Digite o segundo numero"));
    var c = parseFloat(prompt("Digite o terceiro numero"));

    if(a==b && a==c && b==c){
        alert("Triangulo equilatero");
    }else if(a!=b!=c){
        alert("Triangulo escaleno")
    }else{
        alert("Triangulo isosceles")
    }
}
