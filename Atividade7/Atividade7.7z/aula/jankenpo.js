let jogador = prompt("Escolha Pedra, Papel ou Tesoura:").toUpperCase();

let opcoes = ["PEDRA", "TESOURA", "PAPEL"];
let computador = opcoes[Math.floor(Math.random() * 3)];

let resultado = "";

if (jogador === computador) {
    resultado = "Empate!";
} else if (
    (jogador === "PEDRA" && computador === "TESOURA") ||
    (jogador === "TESOURA" && computador === "PAPEL") ||
    (jogador === "PAPEL" && computador === "PEDRA")
) {
    resultado = "Você venceu!";
} else if (
    (jogador === "PEDRA" && computador === "PAPEL") ||
    (jogador === "TESOURA" && computador === "PEDRA") ||
    (jogador === "PAPEL" && computador === "TESOURA")
) {
    resultado = "Você perdeu!";
} else {
    resultado = "Jogada inválida!";
}

alert(`Sua jogada: ${jogador}\nJogada do computador: ${computador}\nResultado: ${resultado}`);
